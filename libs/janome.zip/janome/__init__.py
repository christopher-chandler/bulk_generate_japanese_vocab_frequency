from janome.version import JANOME_VERSION as __version__

__all__ = [
    "__version__",
]
